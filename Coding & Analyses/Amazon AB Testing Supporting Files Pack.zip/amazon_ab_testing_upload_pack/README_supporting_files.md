# Supporting analysis files

This folder contains the supporting files for the Amazon-inspired synthetic A/B testing portfolio project.

- `analysis/ab_testing_analysis.ipynb`: Python analysis, statistical tests, commercial scenarios and Power BI CSV exports.
- `sql/ab_testing_workflow.sql`: PostgreSQL validation and experiment-integrity workflow. Import the four raw CSVs in `data/` into tables with matching names before running the SQL stages.
- `data/checkout_session_analysis.csv`: session-level analysis dataset used by the notebook.
- `data/checkout_orders.csv`: order-level values used by the revenue-per-session analysis and SQL checks.
- `data/checkout_exposures.csv`, `data/session_outcomes.csv`, `data/checkout_order_items.csv`: raw synthetic tables for the SQL workflow.
- `output/`: generated Power BI CSVs after the notebook is run.

## Reproduce the notebook

Install dependencies with `pip install -r requirements.txt`, then open `analysis/ab_testing_analysis.ipynb` in Jupyter and run **Restart Kernel and Run All Cells**. The notebook resolves data files from this folder structure and writes exports to `output/`.

All data are synthetic. The scenario calculations are illustrative gross-revenue estimates, not forecasts or profit estimates.
